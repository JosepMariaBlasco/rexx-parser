User Guide
==========

-------------------------------

Contents
--------

- [Installation](install/)
- [First steps](first-steps/)
- [Error handling](errors/)
- [The Element API](elementapi/)
- [The Tree API](treeapi/)