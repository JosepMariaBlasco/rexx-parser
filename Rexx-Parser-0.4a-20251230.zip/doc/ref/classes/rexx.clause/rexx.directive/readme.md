The Rexx.Directive class
========================

TBD

Superclass: [Rexx.Clause](../)

Subclasses:

+ [Method.Directive](method.directive/)