Experimental features
=====================

--------------------

The Rexx Parser includes a set of optional, experimental, features.
These features are not stable, may not perform as advertised,
and can disappear from one version to the next without warning.

+ [erexx: The compiler for experimental Rexx features](../utilities/erexx/)
+ [Class extension](classextensions)
