Una paloma blanca
```
a==
```
a los ojos me miró
