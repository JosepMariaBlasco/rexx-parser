Una paloma
```executor
use strict auto named arg
```
blanca