The Tree API
============

--------------------------------

Two APIs
--------

The [Rexx Parser](/rexx-parser/) defines two Application Programming Interfaces (APIs)
to manipulate a parsed program, **the Tree API**, described here,
and [**the Element API**](/rexx-parser/doc/guide/elementapi/), described elsewhere.
In many cases, you will want to use the two APIs, combined,
to develop your application.

\[To be documented\]