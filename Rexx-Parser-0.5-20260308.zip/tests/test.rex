  Say "Hi"
