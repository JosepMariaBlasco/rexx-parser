A title
=======

Some text

~~~rexx
-- A comment

If a = 1 | "b" = 2**3 Then Say "Hi"
Else "NOPE"
~~~

More text