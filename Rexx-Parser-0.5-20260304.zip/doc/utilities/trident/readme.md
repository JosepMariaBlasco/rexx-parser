Trident
=======

----------------

Trident ("TRee IDENtity") is a self-consistency utility.
It checks that a program is identical to the its own parse Tree.

Usage
-----

<pre>
[rexx] trident [<em>options</em>] <em>file</em>
</pre>

Options
-------

---------------------------------- ------------------------------
`-it`, `--itrace`                  Print internal traceback on error
`-xtr`, `--executor`&nbsp;&nbsp;   Enable Executor support
`-h`, `--help`                     Display this information
---------------------------------- ------------------------------

Program source
--------------

~~~rexx {source=../../../bin/trident.rex}
~~~