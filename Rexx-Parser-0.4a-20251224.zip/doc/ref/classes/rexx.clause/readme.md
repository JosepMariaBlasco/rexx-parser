The Rexx.Clause class
=====================

TBD

Subclasses:

+ [Rexx.Directive](rexx.directive/)