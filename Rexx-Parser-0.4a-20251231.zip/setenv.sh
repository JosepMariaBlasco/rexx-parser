# Call it using ". ./setenv.sh", else export will not work!
echo "Setting env"
export PATH=$(pwd)/bin:$PATH