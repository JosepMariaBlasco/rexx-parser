Say "Hi"
