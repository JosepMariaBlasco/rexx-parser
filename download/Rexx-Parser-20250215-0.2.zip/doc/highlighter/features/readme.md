Highlighter features
====================

--------------------------------------

- [Variable symbol highlighting](var-symbol/).
- [Compound variable highlighting](compound-variable/).
- [Function and subroutine calls](calls/).
- [Taken constant discrimination](taken-constant/).
- [Doc-comments](doc-comments/).
- [Style patches](patches/).
