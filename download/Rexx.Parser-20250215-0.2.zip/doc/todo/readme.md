Todo list
=========

---------------------------

\[See also [the version history](/rexx.parser/doc/history/)\].

Next release (0.2 refresh -- Not released yet)
-----------------------------------------------

### Features

+ [Documentation] Differences between marker elements and special elements.

### Bugs

+ Fenced code blocks get an ID even when it is not really needed.
+ Unicode labels like "&lt;Control-000A&gt;"U are not recognized.

Following releases (in no special order)
----------------------------------------

+ Include optional support for Jean-Louis Faucher's Executor.
