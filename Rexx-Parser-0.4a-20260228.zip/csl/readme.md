Citation Style Language Styles
==============================

-------------------------------

This directory contains
[Citation Style Language](https://citationstyles.org/)
styles downloaded from the
[official Github repository](https://github.com/citation-style-language/styles).
All styles use the
[Creative Commons Attribution ShareAlike 3.0 Unported license](https://creativecommons.org/licenses/by-sa/3.0/).