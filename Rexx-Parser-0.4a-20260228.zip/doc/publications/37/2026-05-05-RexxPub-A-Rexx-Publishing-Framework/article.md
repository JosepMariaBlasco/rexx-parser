RexxPub: A Rexx Publishing Framework <small>Work in Progress</small> {.title}
==================================================================================================

## [Josep Maria Blasco](https://www.epbcn.com/equipo/josep-maria-blasco/)             {.author}
## Espacio Psicoanalítico de Barcelona <br> Balmes, 32, 2º 1ª &mdash; 08007 Barcelona {.affiliation}
## jose.maria.blasco@gmail.com                                                        {.email}
## +34 93 454 89 78 {.phone}

## May the 5<sup>th</sup>, 2026 {.date}

Notice
======

*The source of this document[^thisDoc] is written in Markdown.*
*It has been converted to HTML by*
*[the Rexx Publisher Framework](https://rexx.epbcn.com/rexx-parser/doc/publisher/)[^publisher].*
*It comfortably mixes normal text and programs beautified by the heavy prettyprinting*
*produced by the Rexx Highlighter,*
*and it can be viewed both as a standard web page and printed as a DIN A4 article,*
*in a format ressembling the one produced by the LaTeX `article` documentclass.*

*The default style for Rexx fenced code blocks is* `dark`*.*
*You can choose the light style by appending a* `style=light`
*parameter to the query string part of the URL of this document.*

[^thisDoc]: <small>URL</small> of this document: <https://www.epbcn.com/pdf/josep-maria-blasco/2026-05-04-The-Rexx-Parser-Revisited.pdf>;
<small>HTML</small> version: <https://rexx.epbcn.com/rexx-parser/doc/publications/37/2026-05-04-The-Rexx-Parser-Revisited/>;
<small>HTML</small> <small>PDF</small>-ready printable version: <https://rexx.epbcn.com/rexx-parser/doc/publications/37/2026-05-04-The-Rexx-Parser-Revisited/?print=pdf>.
Presented to the [37th International Rexx Language Symposium](https://www.rexxla.org/document.rsp?base=events&year=2026&doc=announcement.html&title=Announcement),
held at the [Espacio Psicoanalítico de Barcelona](https://www.epbcn.com/) and online from the 3th to the 6th of May, 2026.

[^publisher]: See <https://rexx.epbcn.com/rexx-parser/doc/publisher/>.
