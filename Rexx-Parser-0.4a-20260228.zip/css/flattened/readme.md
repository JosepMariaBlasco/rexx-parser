What's this directory for?
==========================

The `/css/flattened` subdirectory contains flattened versions
of the CSS files found in `/css`. They will be needed until
the internal Chromium version used by `pagedjs-cli`
supports the unflattened versions.

You can use `flattencss.rex`to produce a `.cmd` file
that you should run in the directory where `postcss`
is installed.