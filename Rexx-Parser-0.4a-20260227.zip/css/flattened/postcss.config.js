module.exports = {
  plugins: [
    require('postcss-nested')
  ]
}