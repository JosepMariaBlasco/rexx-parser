37th International Rexx Language Symposium
==========================================

#### May 3&ndash;May 6, 2026 &mdash; EPBCN, Barcelona, Catalunya, Spain and online

- [The Rexx Parser Revisited: Highlights and New Features](2026-05-04-The-Rexx-Parser-Revisited/) (2026-05-04).
- [RexxPub: A Rexx Publishing Framework from a Single Markdown Source. Work in Progress](2026-05-05-RexxPub-A-Rexx-Publishing-Framework) (2026-05-05).
