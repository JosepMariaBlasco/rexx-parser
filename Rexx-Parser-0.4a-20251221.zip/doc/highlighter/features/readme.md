Highlighter features
====================

--------------------------------------

- [Variable symbol highlighting](var-symbol/).
- [Compound variable highlighting](compound-variable/).
- [Detailed string highlighing](strings/).
- [Detailed number highlighing](numbers/).
- [Function and subroutine calls](calls/).
- [Taken constant discrimination](taken-constant/).
- [Doc-comments](doc-comments/).
- [Style patches](patches/).
